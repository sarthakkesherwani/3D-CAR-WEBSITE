// Local npm registry backed by the npm cacache store.
// Synthesizes packuments from cached tarballs so `npm install` works offline.
import { createRequire } from 'node:module';
import http from 'node:http';
import zlib from 'node:zlib';

const NPM_LIB = '/Users/sarthak/.nvm/versions/node/v22.23.1/lib/node_modules/npm/node_modules';
const req = createRequire(NPM_LIB + '/');
const cacache = req('cacache');
const tar = req('tar');
const semver = req('semver');

const CACHE = process.env.HOME + '/.npm/_cacache';
const PORT = 4873;

// url -> { integrity }
const tarballs = new Map();
// name -> [version...]
const byName = new Map();
// url -> manifest (memoized package.json reads)
const manifestCache = new Map();

const TARBALL_RE = /^make-fetch-happen:request-cache:(https:\/\/registry\.npmjs\.org\/((?:@[^/]+\/)?[^/]+)\/-\/[^/]+-(\d+\.\d+\.\d+[^/]*?)\.tgz)$/;

async function index() {
  const entries = await cacache.ls(CACHE);
  for (const [key, entry] of Object.entries(entries)) {
    const m = key.match(TARBALL_RE);
    if (!m || !entry.integrity) continue;
    const [, url, name, version] = m;
    tarballs.set(url, { integrity: entry.integrity, name, version });
    if (!byName.has(name)) byName.set(name, []);
    byName.get(name).push({ version, url });
  }
  console.log(`indexed ${tarballs.size} tarballs, ${byName.size} packages`);
}

function readManifest(url) {
  if (manifestCache.has(url)) return manifestCache.get(url);
  const p = new Promise((resolve, reject) => {
    const { integrity } = tarballs.get(url);
    const src = cacache.get.stream.byDigest(CACHE, integrity);
    const gunzip = zlib.createGunzip();
    const parser = new tar.Parser();
    let best = null; // shortest path ending in /package.json
    parser.on('entry', (e) => {
      const parts = e.path.split('/');
      if (parts.length === 2 && parts[1] === 'package.json') {
        const chunks = [];
        e.on('data', (c) => chunks.push(c));
        e.on('end', () => { best = Buffer.concat(chunks); });
      } else e.resume();
    });
    parser.on('end', () => {
      if (!best) return reject(new Error('no package.json in ' + url));
      try { resolve(JSON.parse(best.toString('utf8'))); }
      catch (err) { reject(err); }
    });
    parser.on('error', reject);
    gunzip.on('error', reject);
    src.on('error', reject);
    src.pipe(gunzip).pipe(parser);
  });
  manifestCache.set(url, p);
  return p;
}

async function packument(name) {
  const versions = byName.get(name);
  if (!versions) return null;
  const doc = { name, 'dist-tags': {}, versions: {} };
  for (const { version, url } of versions) {
    let pj;
    try { pj = await readManifest(url); }
    catch (e) { console.error(`skip ${name}@${version}: ${e.message}`); continue; }
    const { integrity } = tarballs.get(url);
    doc.versions[version] = {
      name, version,
      dependencies: pj.dependencies || {},
      optionalDependencies: pj.optionalDependencies || {},
      peerDependencies: pj.peerDependencies || {},
      peerDependenciesMeta: pj.peerDependenciesMeta,
      bundleDependencies: pj.bundleDependencies || pj.bundledDependencies,
      bin: pj.bin, engines: pj.engines, os: pj.os, cpu: pj.cpu,
      hasInstallScript: !!(pj.scripts && (pj.scripts.install || pj.scripts.preinstall || pj.scripts.postinstall)),
      dist: { tarball: `http://localhost:${PORT}/t/${encodeURIComponent(url)}`, integrity },
    };
  }
  const vers = Object.keys(doc.versions);
  if (!vers.length) return null;
  const stable = vers.filter((v) => !semver.prerelease(v));
  doc['dist-tags'].latest = (stable.length ? stable : vers).sort(semver.rcompare)[0];
  return doc;
}

const server = http.createServer(async (rq, rs) => {
  try {
    const u = decodeURIComponent(rq.url);
    if (u.startsWith('/t/')) {
      const url = decodeURIComponent(rq.url.slice(3));
      const t = tarballs.get(url);
      if (!t) { rs.writeHead(404).end('no tarball'); return; }
      rs.writeHead(200, { 'content-type': 'application/octet-stream' });
      cacache.get.stream.byDigest(CACHE, t.integrity).pipe(rs);
      return;
    }
    const name = u.replace(/^\//, '').split('?')[0];
    const doc = await packument(name);
    if (!doc) { console.log('404', name); rs.writeHead(404, { 'content-type': 'application/json' }).end('{"error":"not found"}'); return; }
    rs.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify(doc));
  } catch (e) {
    console.error('ERR', rq.url, e.message);
    rs.writeHead(500).end(e.message);
  }
});

await index();
server.listen(PORT, '127.0.0.1', () => console.log(`registry on http://localhost:${PORT}`));
