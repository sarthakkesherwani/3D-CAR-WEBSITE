// Offline npm installer: resolves deps from ~/.npm/_cacache tarballs and
// extracts a hoisted node_modules. No network, no registry.
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const NPM_LIB = '/Users/sarthak/.nvm/versions/node/v22.23.1/lib/node_modules/npm/node_modules';
const req = createRequire(NPM_LIB + '/');
const cacache = req('cacache');
const tar = req('tar');
const semver = req('semver');

const CACHE = process.env.HOME + '/.npm/_cacache';
const ROOT = process.cwd();
const NM = path.join(ROOT, 'node_modules');

const TARBALL_RE = /^make-fetch-happen:request-cache:(https:\/\/registry\.npmjs\.org\/((?:@[^/]+\/)?[^/]+)\/-\/[^/]+-(\d+\.\d+\.\d+[^/]*?)\.tgz)$/;

// ---- index cache ----
const avail = new Map(); // name -> Map(version -> integrity)
const entries = await cacache.ls(CACHE);
for (const [key, entry] of Object.entries(entries)) {
  const m = key.match(TARBALL_RE);
  if (!m || !entry.integrity) continue;
  const [, , name, version] = m;
  if (!avail.has(name)) avail.set(name, new Map());
  avail.get(name).set(version, entry.integrity);
}
console.log(`index: ${avail.size} packages`);

// ---- helpers ----
function pick(name, range) {
  const vers = avail.get(name);
  if (!vers) return null;
  const list = [...vers.keys()].sort(semver.rcompare);
  const ok = list.find((v) => semver.satisfies(v, range, { includePrerelease: false }));
  return ok || null;
}

const manifests = new Map(); // name@version -> pkgjson
async function manifest(name, version) {
  const k = `${name}@${version}`;
  if (manifests.has(k)) return manifests.get(k);
  const integrity = avail.get(name).get(version);
  const pj = await new Promise((resolve, reject) => {
    const src = cacache.get.stream.byDigest(CACHE, integrity);
    const gunzip = zlib.createGunzip();
    const parser = new tar.Parser();
    let buf = null;
    parser.on('entry', (e) => {
      const parts = e.path.split('/');
      if (parts.length === 2 && parts[1] === 'package.json' && !buf) {
        const chunks = [];
        e.on('data', (c) => chunks.push(c));
        e.on('end', () => { buf = Buffer.concat(chunks); });
      } else e.resume();
    });
    parser.on('end', () => {
      if (!buf) return reject(new Error('no package.json'));
      resolve(JSON.parse(buf.toString('utf8')));
    });
    parser.on('error', reject);
    src.on('error', reject).pipe(gunzip).on('error', reject).pipe(parser);
  });
  manifests.set(k, pj);
  return pj;
}

async function extract(name, version, dest) {
  const integrity = avail.get(name).get(version);
  fs.mkdirSync(dest, { recursive: true });
  await new Promise((resolve, reject) => {
    const src = cacache.get.stream.byDigest(CACHE, integrity);
    const x = tar.x({ cwd: dest, strip: 1 });
    x.on('finish', resolve).on('error', reject);
    src.on('error', reject).pipe(x);
  });
}

// ---- resolve (hoisted) ----
const rootPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const rootDeps = { ...rootPkg.dependencies, ...rootPkg.devDependencies };

const hoisted = new Map(); // name -> {version, deps}
const nested = []; // {parentPath: [names...], name, version}
const missing = [];
const seen = new Set();

async function resolveDeps(name, version, chain) {
  const key = `${name}@${version}`;
  if (seen.has(key)) return;
  seen.add(key);
  const pj = await manifest(name, version);
  const deps = { ...pj.dependencies };
  for (const [dn, drange] of Object.entries(pj.optionalDependencies || {})) deps[dn] = drange;
  for (const [dn, drange] of Object.entries(deps)) {
    const isOptional = !!(pj.optionalDependencies && pj.optionalDependencies[dn]);
    let dv = pick(dn, drange);
    if (!dv) {
      if (isOptional) continue;
      missing.push(`${dn}@${drange} (needed by ${key})`);
      continue;
    }
    // platform filter for optional natives
    const dpj = await manifest(dn, dv);
    if (dpj.os && !dpj.os.includes('darwin')) continue;
    if (dpj.cpu && !dpj.cpu.includes('arm64')) continue;
    const h = hoisted.get(dn);
    if (!h) {
      hoisted.set(dn, { version: dv });
      await resolveDeps(dn, dv, [...chain, dn]);
    } else if (h.version !== dv) {
      if (semver.satisfies(h.version, drange)) continue; // hoisted works
      nested.push({ under: chain[chain.length - 1] ? name : name, host: name, hostVersion: version, name: dn, version: dv });
      await resolveDeps(dn, dv, [...chain, dn]);
    }
  }
}

for (const [dn, drange] of Object.entries(rootDeps)) {
  const dv = pick(dn, drange);
  if (!dv) { missing.push(`${dn}@${drange} (root)`); continue; }
  hoisted.set(dn, { version: dv });
}
for (const [dn] of Object.entries(rootDeps)) {
  const h = hoisted.get(dn);
  if (h) await resolveDeps(dn, h.version, [dn]);
}

if (missing.length) {
  console.log('MISSING:\n' + [...new Set(missing)].join('\n'));
  process.exit(2);
}

// ---- extract ----
fs.rmSync(NM, { recursive: true, force: true });
let n = 0;
for (const [name, { version }] of hoisted) {
  await extract(name, version, path.join(NM, name));
  n++;
}
for (const item of nested) {
  const hostDir = path.join(NM, item.host, 'node_modules', item.name);
  await extract(item.name, item.version, hostDir);
  n++;
}
console.log(`extracted ${n} packages (${nested.length} nested)`);

// ---- bin links ----
const binDir = path.join(NM, '.bin');
fs.mkdirSync(binDir, { recursive: true });
for (const [name, { version }] of hoisted) {
  const pj = await manifest(name, version);
  if (!pj.bin) continue;
  const bins = typeof pj.bin === 'string' ? { [name.split('/').pop()]: pj.bin } : pj.bin;
  for (const [bn, target] of Object.entries(bins)) {
    const abs = path.join(NM, name, target);
    const link = path.join(binDir, bn);
    try { fs.chmodSync(abs, 0o755); } catch {}
    try { fs.rmSync(link, { force: true }); fs.symlinkSync(path.relative(binDir, abs), link); } catch (e) { console.log('bin skip', bn, e.message); }
  }
}
console.log('done');
