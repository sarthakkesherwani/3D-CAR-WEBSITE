import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Environment, Lightformer, ContactShadows } from '@react-three/drei'
import * as THREE from 'three'
import { useStore } from '../store.js'
import { accentFor } from '../config.js'
import { floorGeo, daisGeo, ringGeo } from './carGeometry.js'

const floorMat = new THREE.MeshStandardMaterial({ color: '#07080a', roughness: 0.32, metalness: 0.85 })
const daisMat = new THREE.MeshStandardMaterial({ color: '#0c0e11', roughness: 0.24, metalness: 0.9 })

export function Studio() {
  const ringMat = useMemo(
    () => new THREE.MeshBasicMaterial({ color: '#5b8cff', toneMapped: false }),
    [],
  )
  const paint = useStore((s) => s.paint)
  const keyRef = useRef()

  useFrame((_, delta) => {
    const d = Math.min(delta, 1 / 30)
    ringMat.color.lerp(new THREE.Color(accentFor(paint)), 1 - Math.exp(-6 * d))
  })

  return (
    <>
      <color attach="background" args={['#050607']} />
      <fog attach="fog" args={['#050607', 16, 30]} />

      <mesh geometry={floorGeo} material={floorMat} rotation={[-Math.PI / 2, 0, 0]} receiveShadow />
      <mesh geometry={daisGeo} material={daisMat} position={[0, 0.03, 0]} receiveShadow />
      <mesh geometry={ringGeo} material={ringMat} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.075, 0]} />

      <ContactShadows position={[0, 0.065, 0]} opacity={0.85} scale={12} blur={2.2} far={2.5} resolution={512} frames={Infinity} />

      <ambientLight intensity={0.1} />
      <hemisphereLight args={['#2c3a58', '#05060a', 0.55]} />
      <directionalLight
        ref={keyRef}
        position={[6, 7, 4]}
        intensity={3.0}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={1}
        shadow-camera-far={22}
        shadow-camera-left={-6}
        shadow-camera-right={6}
        shadow-camera-top={6}
        shadow-camera-bottom={-6}
        shadow-bias={-0.0004}
      />
      <directionalLight position={[-7, 4, -5]} intensity={1.1} color="#7ea6ff" />
      <directionalLight position={[2, 2.5, -8]} intensity={0.9} color="#e8f1ff" />
      <spotLight position={[0, 9, 0]} angle={0.5} penumbra={1} intensity={1.6} color="#fff6e6" />

      {/* Procedural studio HDR: softbox lightformers baked to an env map */}
      <Environment resolution={512} frames={1}>
        <Lightformer intensity={4} rotation-x={Math.PI / 2} position={[0, 5, 0]} scale={[10, 6, 1]} />
        <Lightformer intensity={1.6} rotation-y={Math.PI / 2} position={[-6, 2, 0]} scale={[7, 2, 1]} color="#cfe2ff" />
        <Lightformer intensity={1.6} rotation-y={-Math.PI / 2} position={[6, 2, 0]} scale={[7, 2, 1]} color="#fff1dd" />
        <Lightformer intensity={1.1} rotation-y={Math.PI} position={[0, 2.5, -7]} scale={[9, 1.6, 1]} />
        <Lightformer intensity={0.8} position={[0, 1.4, 7]} scale={[8, 1.2, 1]} color="#e8eeff" />
        <Lightformer form="ring" intensity={2.5} position={[0, 6, -4]} scale={3} color="#ffffff" />
      </Environment>
    </>
  )
}

// Drifting dust / light-streak particles
export function Particles({ count = 260 }) {
  const points = useRef()
  const { positions, seeds } = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const seeds = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const r = 4 + Math.random() * 9
      const a = Math.random() * Math.PI * 2
      positions[i * 3] = Math.cos(a) * r
      positions[i * 3 + 1] = 0.2 + Math.random() * 5
      positions[i * 3 + 2] = Math.sin(a) * r
      seeds[i] = Math.random() * 100
    }
    return { positions, seeds }
  }, [count])

  useFrame((state) => {
    if (!points.current) return
    const t = state.clock.elapsedTime
    const pos = points.current.geometry.attributes.position
    for (let i = 0; i < count; i++) {
      pos.array[i * 3 + 1] += Math.sin(t * 0.4 + seeds[i]) * 0.0012
      pos.array[i * 3] += Math.cos(t * 0.25 + seeds[i] * 2) * 0.0009
    }
    pos.needsUpdate = true
    points.current.rotation.y = t * 0.012
  })

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.02} color="#8fb8ff" transparent opacity={0.4} sizeAttenuation depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  )
}
