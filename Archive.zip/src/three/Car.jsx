import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useStore } from '../store.js'
import { turntable } from '../scrollState.js'
import * as G from './carGeometry.js'

const DAMP = THREE.MathUtils.damp

// shared static materials
const tireMat = new THREE.MeshStandardMaterial({ color: '#141414', roughness: 0.95, metalness: 0 })
const chromeMat = new THREE.MeshStandardMaterial({ color: '#e8ebef', roughness: 0.08, metalness: 1 })
const trimMat = new THREE.MeshStandardMaterial({ color: '#0a0b0d', roughness: 0.4, metalness: 0.65 })
const linerMat = new THREE.MeshBasicMaterial({ color: '#020203', side: THREE.DoubleSide })
const rotorMat = new THREE.MeshStandardMaterial({ color: '#767b82', roughness: 0.3, metalness: 0.95 })
const caliperMat = new THREE.MeshStandardMaterial({ color: '#d9a520', roughness: 0.35, metalness: 0.45 })
const leatherMat = new THREE.MeshStandardMaterial({ color: '#41302a', roughness: 0.85, metalness: 0 })
const dashMat = new THREE.MeshStandardMaterial({ color: '#101114', roughness: 0.55, metalness: 0.25 })
const screenMat = new THREE.MeshStandardMaterial({
  color: '#04070d', emissive: '#2470ff', emissiveIntensity: 1.1, roughness: 0.2,
})
const glassMat = new THREE.MeshPhysicalMaterial({
  color: '#0a0f14', metalness: 0, roughness: 0.06,
  transmission: 0.5, thickness: 0.05, ior: 1.5,
  transparent: true, opacity: 0.94, envMapIntensity: 1.8,
})
const headlightMat = new THREE.MeshPhysicalMaterial({
  color: '#9fb4cc', emissive: '#b8d4ff', emissiveIntensity: 0.7,
  roughness: 0.12, metalness: 0.3, clearcoat: 1,
})
const tailMat = new THREE.MeshStandardMaterial({
  color: '#30060b', emissive: '#ff1626', emissiveIntensity: 3.2, roughness: 0.25, toneMapped: false,
})

function Wheel({ pos, side, rimMat, spinRefs }) {
  const spinner = useRef()
  spinRefs.current.push(spinner)
  return (
    <group position={pos}>
      {/* brakes — static */}
      <mesh geometry={G.rotorGeo} material={rotorMat} position={[0, 0, side * -0.02]} />
      <mesh
        geometry={G.caliperGeo}
        material={caliperMat}
        position={[0, 0, side * -0.01]}
        rotation={[0, 0, side === 1 ? 2.75 : 0.05]}
      />
      {/* spinning assembly */}
      <group ref={spinner}>
        <mesh geometry={G.tireGeo} material={tireMat} castShadow />
        <mesh geometry={G.tireShoulderGeo} material={tireMat} position={[0, 0, side * 0.09]} />
        <mesh geometry={G.rimFaceGeo} material={rimMat} position={[0, 0, side * 0.045]} />
        <mesh geometry={G.rimLipGeo} material={rimMat} position={[0, 0, side * 0.115]} />
        {Array.from({ length: 7 }, (_, i) => (
          <mesh
            key={i}
            geometry={G.spokeGeo}
            material={rimMat}
            position={[0, 0, side * 0.1]}
            rotation={[0, 0, (i / 7) * Math.PI * 2]}
          />
        ))}
        <mesh geometry={G.hubCapGeo} material={chromeMat} position={[0, 0, side * 0.13]} />
      </group>
    </group>
  )
}

export default function Car() {
  const paint = useStore((s) => s.paint)
  const finish = useStore((s) => s.finish)
  const rim = useStore((s) => s.rim)

  const group = useRef()
  const spinRefs = useRef([])
  spinRefs.current = []
  const targetPaint = useMemo(() => new THREE.Color(), [])
  const targetRim = useMemo(() => new THREE.Color(), [])

  const paintMat = useMemo(
    () => new THREE.MeshPhysicalMaterial({
      color: paint, metalness: 0.9, roughness: 0.3,
      clearcoat: 1, clearcoatRoughness: 0.06, envMapIntensity: 1.3,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  )
  const rimMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: rim, roughness: 0.22, metalness: 1 }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  )

  useFrame((state, delta) => {
    const d = Math.min(delta, 1 / 30)
    const k = 1 - Math.exp(-8 * d)
    paintMat.color.lerp(targetPaint.set(paint), k)
    rimMat.color.lerp(targetRim.set(rim), k)
    const matte = finish === 'matte'
    paintMat.roughness = DAMP(paintMat.roughness, matte ? 0.6 : 0.3, 8, d)
    paintMat.clearcoat = DAMP(paintMat.clearcoat, matte ? 0.12 : 1, 8, d)
    paintMat.metalness = DAMP(paintMat.metalness, matte ? 0.5 : 0.9, 8, d)
    paintMat.envMapIntensity = DAMP(paintMat.envMapIntensity, matte ? 0.7 : 1.3, 8, d)

    if (group.current) {
      group.current.rotation.y = turntable.angle
      group.current.position.y = 0.035 + Math.sin(state.clock.elapsedTime * 0.55) * 0.007
    }
    for (const r of spinRefs.current) {
      if (r.current) r.current.rotation.z -= turntable.vel * 3.2
    }
  })

  return (
    <group ref={group} position={[0, 0.035, 0]}>
      {/* hull + greenhouse */}
      <mesh geometry={G.bodyGeo} material={paintMat} castShadow receiveShadow />
      <mesh geometry={G.cabinGeo} material={paintMat} castShadow />
      <mesh geometry={G.glassGeo} material={glassMat} />
      <mesh geometry={G.floorPlateGeo} material={trimMat} />

      {/* arch liners hide hull interior behind wheels */}
      {G.WHEELS.map((w, i) => (
        <mesh key={i} geometry={G.archLinerGeo} material={linerMat} position={[w.pos[0], w.pos[1], w.pos[2] * 0.88]} />
      ))}

      {/* trim */}
      <mesh geometry={G.splitterGeo} material={trimMat} />
      <mesh geometry={G.fasciaGeo} material={trimMat} />
      <mesh geometry={G.rockerGeo} material={trimMat} position={[0, 0.2, 0.87]} />
      <mesh geometry={G.rockerGeo} material={trimMat} position={[0, 0.2, -0.87]} />
      <mesh geometry={G.diffuserGeo} material={trimMat} />
      <mesh geometry={G.spoilerGeo} material={paintMat} castShadow />

      {/* lights */}
      <mesh geometry={G.headlightGeo} material={headlightMat} position={[2.02, 0.5, 0.5]} rotation={[0.2, -0.5, 0.35]} scale={[0.55, 0.65, 0.7]} />
      <mesh geometry={G.headlightGeo} material={headlightMat} position={[2.02, 0.5, -0.5]} rotation={[-0.2, 0.5, 0.35]} scale={[0.55, 0.65, 0.7]} />
      <mesh geometry={G.drlGeo} material={headlightMat} position={[2.18, 0.38, 0.4]} rotation={[0, -0.4, 0]} scale={0.8} />
      <mesh geometry={G.drlGeo} material={headlightMat} position={[2.18, 0.38, -0.4]} rotation={[0, 0.4, 0]} scale={0.8} />
      <mesh geometry={G.tailBarGeo} material={tailMat} position={[-2.31, 0.78, 0]} />
      <mesh geometry={G.exhaustGeo} material={chromeMat} position={[-2.28, 0.34, 0.32]} />
      <mesh geometry={G.exhaustGeo} material={chromeMat} position={[-2.28, 0.34, -0.32]} />

      {/* interior — kept below the greenhouse glass line */}
      <group position={[0, -0.14, 0]} scale={0.88}>
        {[0.34, -0.34].map((z) => (
          <group key={z} position={[-0.5, 0.82, z]}>
            <mesh geometry={G.seatBaseGeo} material={leatherMat} />
            <mesh geometry={G.seatBackGeo} material={leatherMat} position={[-0.22, 0.2, 0]} />
            <mesh geometry={G.headrestGeo} material={leatherMat} position={[-0.31, 0.46, 0]} />
          </group>
        ))}
        <mesh geometry={G.consoleGeo} material={dashMat} position={[-0.1, 0.86, 0]} />
        <mesh geometry={G.dashGeo} material={dashMat} position={[0.45, 0.95, 0]} />
        <mesh geometry={G.screenGeo} material={screenMat} position={[0.36, 1.05, 0]} rotation={[0, 0, -0.14]} />
        <mesh geometry={G.columnGeo} material={dashMat} position={[0.18, 0.9, 0.34]} rotation={[0, 0, 1.12]} />
        <mesh geometry={G.wheelRingGeo} material={leatherMat} position={[0.06, 0.97, 0.34]} rotation={[0.2, 1.57, 0]} />
      </group>

      {/* wheels */}
      {G.WHEELS.map((w, i) => (
        <Wheel key={i} pos={w.pos} side={w.side} rimMat={rimMat} spinRefs={spinRefs} />
      ))}
    </group>
  )
}
