import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import Car from './Car.jsx'
import { Studio, Particles } from './Stage.jsx'
import { KEYFRAMES, ROTATABLE } from '../config.js'
import { camState, turntable, currentSeg } from '../scrollState.js'

const easeInOut = (t) => t * t * (3 - 2 * t)
const vA = new THREE.Vector3()
const vB = new THREE.Vector3()
const lookCur = new THREE.Vector3(0, 0.55, 0)
const posCur = new THREE.Vector3(...KEYFRAMES[0].pos)

export default function Experience() {
  const gl = useThree((s) => s.gl)
  const dragRef = useRef({ px: 0 })

  // Pointer drag → turntable, only on rotatable sections
  useEffect(() => {
    const el = gl.domElement
    const down = (e) => {
      const { seg } = currentSeg()
      if (!ROTATABLE.has(seg)) return
      turntable.dragging = true
      dragRef.current.px = e.clientX ?? e.touches?.[0]?.clientX ?? 0
      el.setPointerCapture?.(e.pointerId)
    }
    const move = (e) => {
      if (!turntable.dragging) return
      const x = e.clientX ?? e.touches?.[0]?.clientX ?? 0
      const dx = x - dragRef.current.px
      dragRef.current.px = x
      turntable.vel = dx * 0.004
      turntable.angle += turntable.vel
      turntable.lastInteraction = performance.now()
    }
    const up = () => (turntable.dragging = false)
    el.addEventListener('pointerdown', down)
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    return () => {
      el.removeEventListener('pointerdown', down)
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
    }
  }, [gl])

  useFrame((state, delta) => {
    const d = Math.min(delta, 1 / 30)
    const { seg, t } = currentSeg()

    // --- turntable physics ---
    if (!turntable.dragging) {
      turntable.vel *= Math.exp(-3.2 * d) // inertia decay
      const idleFor = performance.now() - turntable.lastInteraction
      if (ROTATABLE.has(seg) && idleFor > 2600) {
        // ease auto-rotate back in
        turntable.vel = THREE.MathUtils.damp(turntable.vel, 0.0016, 1.2, d)
      }
      turntable.angle += turntable.vel
    }
    // On non-rotatable sections, settle the car back to its keyframed pose
    if (!ROTATABLE.has(seg) && !turntable.dragging) {
      const settled = Math.round(turntable.angle / (Math.PI * 2)) * Math.PI * 2
      turntable.angle = THREE.MathUtils.damp(turntable.angle, settled, 2.5, d)
    }

    // --- camera path ---
    const from = KEYFRAMES[Math.max(0, seg - 1)]
    const to = KEYFRAMES[seg]
    const k = easeInOut(THREE.MathUtils.clamp(t, 0, 1))
    vA.set(...from.pos).lerp(vB.set(...to.pos), k)
    // slight orbital sway for life
    const sway = Math.sin(state.clock.elapsedTime * 0.3) * 0.06
    vA.x += sway
    vA.y += Math.cos(state.clock.elapsedTime * 0.23) * 0.03

    posCur.lerp(vA, 1 - Math.exp(-5.5 * d))
    state.camera.position.copy(posCur)

    vA.set(...from.look).lerp(vB.set(...to.look), k)
    lookCur.lerp(vA, 1 - Math.exp(-5.5 * d))
    state.camera.lookAt(lookCur)
  })

  return (
    <>
      <Studio />
      <Particles />
      <Car />
    </>
  )
}
