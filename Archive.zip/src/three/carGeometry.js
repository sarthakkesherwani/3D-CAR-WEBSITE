import * as THREE from 'three'
import { loftGeometry } from './loft.js'

// Built once at module load, shared across renders.
// Car spans x ∈ [-2.35, 2.35] (rear → front), ground at y=0.
// Wheel centers: x=±1.45, y=0.33, z=±0.85. Tire outer radius 0.3.

const WHEEL_Y = 0.33
const ARCH_R = 0.34 // arch opening radius (lofted into yB)

// yB dips up over the wheel arches so the hull has real cutouts
const archY = (x, cx) => {
  const d = Math.abs(x - cx)
  if (d >= ARCH_R) return null
  return WHEEL_Y + Math.sqrt(ARCH_R * ARCH_R - d * d) * 1.02
}
const baseYB = (x) => {
  // sill line with raised nose/tail overhangs
  if (x < -1.9) return 0.24 + (-x - 1.9) * 0.16
  if (x > 1.9) return 0.24 + (x - 1.9) * 0.15
  return 0.23
}
const yB = (x) => {
  const a = archY(x, -1.45) ?? archY(x, 1.45)
  return a != null ? Math.max(a, baseYB(x)) : baseYB(x)
}

// silhouette: [x, halfWidth, roofline, sideFullness, crownFullness]
const PROFILE = [
  [-2.35, 0.80, 0.74, 0.60, 0.94],
  [-2.24, 0.92, 0.86, 0.64, 0.90],
  [-2.05, 0.98, 0.95, 0.68, 0.86],
  [-1.80, 1.00, 0.99, 0.71, 0.85],
  [-1.60, 1.00, 0.99, 0.72, 0.85],
  [-1.45, 1.00, 0.98, 0.72, 0.85], // rear arch crest
  [-1.30, 0.99, 0.96, 0.73, 0.85],
  [-1.12, 0.97, 0.93, 0.74, 0.86],
  [-0.85, 0.95, 0.90, 0.75, 0.86],
  [-0.50, 0.93, 0.87, 0.76, 0.87],
  [-0.10, 0.92, 0.85, 0.76, 0.87],
  [0.35, 0.93, 0.83, 0.75, 0.87],
  [0.75, 0.95, 0.81, 0.73, 0.87],
  [1.10, 0.97, 0.80, 0.71, 0.88],
  [1.30, 0.97, 0.80, 0.70, 0.88],
  [1.45, 0.96, 0.79, 0.69, 0.88], // front arch crest
  [1.60, 0.94, 0.76, 0.68, 0.89],
  [1.80, 0.90, 0.68, 0.66, 0.90],
  [2.00, 0.84, 0.58, 0.63, 0.92],
  [2.16, 0.75, 0.49, 0.60, 0.94],
  [2.28, 0.63, 0.42, 0.57, 0.97],
  [2.35, 0.50, 0.37, 0.54, 1.0],
]

// densify around the arches so the cutout curve is smooth
const XS = []
for (let i = 0; i < PROFILE.length - 1; i++) {
  const [x0] = PROFILE[i]
  const [x1] = PROFILE[i + 1]
  XS.push(x0)
  const nearArch =
    (x0 > -1.85 && x1 < -1.05) || (x0 > 1.05 && x1 < 1.85)
  const steps = nearArch ? 4 : 1
  for (let s = 1; s < steps; s++) XS.push(x0 + ((x1 - x0) * s) / steps)
}
XS.push(PROFILE[PROFILE.length - 1][0])

const lerpProfile = (x) => {
  let i = 0
  while (i < PROFILE.length - 2 && PROFILE[i + 1][0] < x) i++
  const a = PROFILE[i]
  const b = PROFILE[i + 1]
  const t = THREE.MathUtils.clamp((x - a[0]) / (b[0] - a[0]), 0, 1)
  const L = (j) => a[j] + (b[j] - a[j]) * t
  return { x, w: L(1), yT: L(2), p: L(3), q: L(4), yB: yB(x) }
}

export const bodyGeo = loftGeometry(XS.map(lerpProfile), 56)

// ---- cabin / greenhouse ----
const CABIN = [
  { x: -1.50, w: 0.76, yT: 0.99, yB: 0.86, p: 0.60, q: 0.90 },
  { x: -1.22, w: 0.79, yT: 1.20, yB: 0.86, p: 0.62, q: 0.80 },
  { x: -0.75, w: 0.80, yT: 1.33, yB: 0.85, p: 0.64, q: 0.78 },
  { x: -0.15, w: 0.78, yT: 1.32, yB: 0.84, p: 0.64, q: 0.78 },
  { x: 0.45, w: 0.72, yT: 1.18, yB: 0.81, p: 0.62, q: 0.80 },
  { x: 0.95, w: 0.62, yT: 0.98, yB: 0.78, p: 0.60, q: 0.85 },
  { x: 1.28, w: 0.50, yT: 0.83, yB: 0.75, p: 0.58, q: 0.90 },
]
export const cabinGeo = loftGeometry(CABIN, 40)

export const glassGeo = (() => {
  const g = cabinGeo.clone()
  const pos = g.getAttribute('position')
  const n = g.getAttribute('normal')
  for (let i = 0; i < pos.count; i++) {
    pos.setXYZ(
      i,
      pos.getX(i) + n.getX(i) * 0.014,
      pos.getY(i) + n.getY(i) * 0.014,
      pos.getZ(i) + n.getZ(i) * 0.014,
    )
  }
  g.computeVertexNormals()
  return g
})()

// ---- underbody / trim ----
export const floorPlateGeo = (() => {
  const g = new THREE.BoxGeometry(3.6, 0.06, 1.34)
  g.translate(0, 0.27, 0)
  return g
})()

export const archLinerGeo = (() => {
  const g = new THREE.CylinderGeometry(0.35, 0.35, 0.26, 28, 1, true)
  g.rotateX(Math.PI / 2)
  return g
})()

export const rockerGeo = (() => {
  const g = new THREE.BoxGeometry(2.2, 0.13, 0.1)
  return g
})()

export const splitterGeo = (() => {
  const shape = new THREE.Shape()
  shape.moveTo(-0.2, -0.92)
  shape.lineTo(0.38, -0.68)
  shape.lineTo(0.5, 0)
  shape.lineTo(0.38, 0.68)
  shape.lineTo(-0.2, 0.92)
  shape.closePath()
  const g = new THREE.ExtrudeGeometry(shape, {
    depth: 0.07, bevelEnabled: true, bevelThickness: 0.015, bevelSize: 0.015, bevelSegments: 2,
  })
  g.rotateX(-Math.PI / 2)
  g.rotateY(Math.PI / 2)
  g.translate(2.0, 0.16, 0)
  return g
})()

export const fasciaGeo = (() => {
  const g = new THREE.BoxGeometry(0.22, 0.16, 1.05)
  g.translate(2.24, 0.29, 0)
  return g
})()

export const diffuserGeo = (() => {
  const g = new THREE.BoxGeometry(0.5, 0.2, 1.4)
  g.rotateZ(-0.32)
  g.translate(-2.18, 0.22, 0)
  return g
})()

// ducktail spoiler — extruded across the car's width (z)
export const spoilerGeo = (() => {
  const shape = new THREE.Shape()
  shape.moveTo(0, 0)
  shape.quadraticCurveTo(-0.18, 0.04, -0.32, 0.15)
  shape.lineTo(-0.27, 0.19)
  shape.quadraticCurveTo(-0.12, 0.09, 0.02, 0.06)
  shape.closePath()
  const g = new THREE.ExtrudeGeometry(shape, { depth: 1.55, bevelEnabled: false })
  g.translate(0, 0, -0.775)
  g.translate(-2.02, 0.9, 0)
  return g
})()

// ---- wheels (axis = Z in local space) ----
export const tireGeo = (() => {
  const g = new THREE.CylinderGeometry(0.3, 0.3, 0.23, 36)
  g.rotateX(Math.PI / 2)
  return g
})()
export const tireShoulderGeo = new THREE.TorusGeometry(0.285, 0.028, 10, 36)
export const rimFaceGeo = (() => {
  const g = new THREE.CylinderGeometry(0.19, 0.19, 0.16, 28)
  g.rotateX(Math.PI / 2)
  return g
})()
export const rimLipGeo = new THREE.TorusGeometry(0.195, 0.015, 8, 32)
export const spokeGeo = (() => {
  const g = new THREE.BoxGeometry(0.048, 0.15, 0.05)
  g.translate(0, 0.11, 0)
  return g
})()
export const hubCapGeo = (() => {
  const g = new THREE.CylinderGeometry(0.045, 0.045, 0.05, 16)
  g.rotateX(Math.PI / 2)
  return g
})()
export const rotorGeo = (() => {
  const g = new THREE.CylinderGeometry(0.155, 0.155, 0.03, 32)
  g.rotateX(Math.PI / 2)
  return g
})()
export const caliperGeo = new THREE.TorusGeometry(0.175, 0.042, 10, 12, Math.PI * 0.4)

export const WHEELS = [
  { pos: [1.45, WHEEL_Y, 0.85], side: 1, front: true },
  { pos: [1.45, WHEEL_Y, -0.85], side: -1, front: true },
  { pos: [-1.45, WHEEL_Y, 0.85], side: 1, front: false },
  { pos: [-1.45, WHEEL_Y, -0.85], side: -1, front: false },
]

// ---- lights ----
export const headlightGeo = (() => {
  const g = new THREE.SphereGeometry(0.085, 18, 12)
  g.scale(0.5, 0.9, 1.8)
  return g
})()
export const drlGeo = (() => {
  const g = new THREE.CapsuleGeometry(0.013, 0.26, 4, 8)
  g.rotateX(Math.PI / 2)
  return g
})()
export const tailBarGeo = (() => {
  const g = new THREE.CapsuleGeometry(0.022, 1.4, 4, 10)
  g.rotateX(Math.PI / 2)
  return g
})()
export const exhaustGeo = (() => {
  const g = new THREE.CylinderGeometry(0.05, 0.058, 0.14, 16)
  g.rotateZ(Math.PI / 2)
  return g
})()

// ---- interior ----
export const seatBaseGeo = new THREE.BoxGeometry(0.48, 0.13, 0.4)
export const seatBackGeo = (() => {
  const g = new THREE.BoxGeometry(0.15, 0.52, 0.4)
  g.rotateZ(0.3)
  return g
})()
export const headrestGeo = new THREE.BoxGeometry(0.12, 0.14, 0.24)
export const dashGeo = (() => {
  const g = new THREE.BoxGeometry(0.3, 0.16, 1.3)
  g.rotateZ(-0.1)
  return g
})()
export const screenGeo = new THREE.BoxGeometry(0.02, 0.12, 0.58)
export const wheelRingGeo = new THREE.TorusGeometry(0.14, 0.022, 10, 24)
export const columnGeo = new THREE.CylinderGeometry(0.024, 0.024, 0.3, 10)
export const consoleGeo = new THREE.BoxGeometry(0.7, 0.16, 0.18)

// ---- environment ----
export const floorGeo = new THREE.CircleGeometry(14, 72)
export const daisGeo = new THREE.CylinderGeometry(3.4, 3.55, 0.06, 96)
export const ringGeo = new THREE.TorusGeometry(3.48, 0.012, 8, 128)
