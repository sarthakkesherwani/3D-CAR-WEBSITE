import * as THREE from 'three'

/**
 * Loft a smooth hull from cross-section "stations" along X.
 * Each station: { x, w, yT, yB, p, q }
 *  - w: half width, yT/yB: top/bottom Y, p: side fullness, q: crown fullness.
 * Profile is a superellipse arch from (-w, yB) over (0, yT) to (w, yB).
 */
export function loftGeometry(stations, M = 48, capStart = true, capEnd = true) {
  const S = stations.length
  const ringSize = M + 1
  const positions = []
  const index = []

  for (let i = 0; i < S; i++) {
    const { x, w, yT, yB, p = 0.78, q = 0.85 } = stations[i]
    for (let j = 0; j <= M; j++) {
      const t = j / M
      const th = Math.PI * (1 - t)
      const c = Math.cos(th)
      const s = Math.sin(th)
      const z = w * Math.sign(c) * Math.pow(Math.abs(c), p)
      const y = yB + (yT - yB) * Math.pow(Math.max(s, 0), q)
      positions.push(x, y, z)
    }
  }

  for (let i = 0; i < S - 1; i++) {
    for (let j = 0; j < M; j++) {
      const a = i * ringSize + j
      const b = a + 1
      const c = a + ringSize
      const d = c + 1
      index.push(a, c, b, b, c, d)
    }
  }

  // End caps: triangle fan to ring centroid
  const cap = (ringStart, flip) => {
    let cx = 0, cy = 0, cz = 0
    for (let j = 0; j <= M; j++) {
      cx += positions[(ringStart + j) * 3]
      cy += positions[(ringStart + j) * 3 + 1]
      cz += positions[(ringStart + j) * 3 + 2]
    }
    const ci = positions.length / 3
    positions.push(cx / ringSize, cy / ringSize, cz / ringSize)
    for (let j = 0; j < M; j++) {
      const a = ringStart + j
      const b = ringStart + j + 1
      if (flip) index.push(ci, b, a)
      else index.push(ci, a, b)
    }
  }
  if (capStart) cap(0, false)
  if (capEnd) cap((S - 1) * ringSize, true)

  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  geo.setIndex(index)
  geo.computeVertexNormals()
  return geo
}
