export default function FeatureCard({ feature }) {
  const right = feature.align === 'right'
  return (
    <div
      data-card={feature.id}
      className={`pointer-events-auto w-[min(88vw,380px)] rounded-2xl border border-white/10 bg-black/45 p-7 backdrop-blur-xl ${right ? 'ml-auto text-right' : ''}`}
      style={{ opacity: 0 }}
    >
      <p className="text-[10px] font-medium uppercase tracking-[0.35em] text-sky-300/80">
        {feature.kicker}
      </p>
      <h3 className="mt-3 font-display text-3xl font-semibold tracking-tight text-white">
        {feature.title}
      </h3>
      <p className="mt-4 text-sm leading-relaxed text-white/60">{feature.body}</p>
      <div className={`mt-6 flex gap-8 ${right ? 'justify-end' : ''}`}>
        {feature.stats.map(([v, l]) => (
          <div key={l}>
            <p className="font-display text-xl font-semibold text-white">{v}</p>
            <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-white/40">{l}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
