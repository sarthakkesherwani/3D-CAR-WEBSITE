import { useStore } from '../store.js'
import { PAINTS, RIMS } from '../config.js'
import { playClick } from '../sound.js'

function Swatch({ hex, name, active, onPick, size = 'h-10 w-10' }) {
  return (
    <button
      type="button"
      title={name}
      aria-label={name}
      aria-pressed={active}
      onClick={() => { onPick(hex); playClick() }}
      className={`${size} rounded-full border transition-all duration-300 ${
        active
          ? 'scale-110 border-white shadow-[0_0_0_3px_rgba(255,255,255,0.15),0_0_24px_rgba(120,170,255,0.35)]'
          : 'border-white/20 hover:scale-105 hover:border-white/60'
      }`}
      style={{ background: `radial-gradient(circle at 32% 30%, ${lighten(hex)}, ${hex} 62%)` }}
    />
  )
}

function lighten(hex) {
  const n = parseInt(hex.slice(1), 16)
  const r = Math.min(255, (n >> 16) + 70)
  const g = Math.min(255, ((n >> 8) & 255) + 70)
  const b = Math.min(255, (n & 255) + 70)
  return `rgb(${r},${g},${b})`
}

export default function Configurator() {
  const { paint, finish, rim, setPaint, setFinish, setRim } = useStore()
  const paintName = PAINTS.find((p) => p.hex === paint)?.name
  const rimName = RIMS.find((r) => r.hex === rim)?.name

  return (
    <div className="pointer-events-auto w-[min(92vw,420px)] rounded-3xl border border-white/10 bg-black/50 p-8 backdrop-blur-2xl">
      <p className="text-[10px] uppercase tracking-[0.4em] text-sky-300/70">06 — Make it yours</p>
      <h3 className="mt-3 font-display text-3xl font-semibold text-white">Configurator</h3>

      <div className="mt-7">
        <div className="flex items-baseline justify-between">
          <p className="text-[11px] uppercase tracking-[0.25em] text-white/45">Exterior paint</p>
          <p className="text-[11px] text-white/70">{paintName}</p>
        </div>
        <div className="mt-3 grid grid-cols-8 gap-2.5">
          {PAINTS.map((p) => (
            <Swatch key={p.hex} {...p} active={paint === p.hex} onPick={setPaint} />
          ))}
        </div>
      </div>

      <div className="mt-7">
        <p className="text-[11px] uppercase tracking-[0.25em] text-white/45">Finish</p>
        <div className="mt-3 grid grid-cols-2 gap-2 rounded-full border border-white/10 bg-white/5 p-1">
          {['glossy', 'matte'].map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => { setFinish(f); playClick() }}
              className={`rounded-full py-2 text-[11px] font-medium uppercase tracking-[0.25em] transition-all ${
                finish === f ? 'bg-white text-black' : 'text-white/55 hover:text-white'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-7">
        <div className="flex items-baseline justify-between">
          <p className="text-[11px] uppercase tracking-[0.25em] text-white/45">Wheel finish</p>
          <p className="text-[11px] text-white/70">{rimName}</p>
        </div>
        <div className="mt-3 flex gap-3">
          {RIMS.map((r) => (
            <Swatch key={r.hex} {...r} active={rim === r.hex} onPick={setRim} size="h-9 w-9" />
          ))}
        </div>
      </div>

      <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-6">
        <div>
          <p className="text-[10px] uppercase tracking-[0.25em] text-white/40">As configured</p>
          <p className="font-display text-2xl font-semibold text-white">$248,000</p>
        </div>
        <button
          type="button"
          onClick={playClick}
          className="rounded-full bg-white px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.25em] text-black transition-transform hover:scale-105"
        >
          Reserve
        </button>
      </div>
    </div>
  )
}
