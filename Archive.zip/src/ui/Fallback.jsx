import { useEffect, useRef, useState } from 'react'
import { useStore } from '../store.js'
import { PAINTS } from '../config.js'

// No-WebGL fallback: a drag-to-spin 360° silhouette carousel rendered on 2D
// canvas (no downloadable imagery available offline, so frames are drawn).
const FRAMES = 36

function drawCarSilhouette(g, w, h, angle, paint) {
  g.clearRect(0, 0, w, h)
  const cx = w / 2
  const cy = h * 0.62
  // squash car width by view angle to fake rotation
  const k = Math.cos(angle)
  const flip = k < 0 ? -1 : 1
  const bw = Math.max(Math.abs(k), 0.22) * w * 0.36
  const side = Math.sin(angle)

  g.save()
  g.translate(cx, cy)
  g.scale(flip, 1)

  // shadow
  g.fillStyle = 'rgba(0,0,0,0.55)'
  g.beginPath()
  g.ellipse(0, h * 0.085, bw * 1.08, h * 0.035, 0, 0, Math.PI * 2)
  g.fill()

  const grad = g.createLinearGradient(0, -h * 0.2, 0, h * 0.08)
  grad.addColorStop(0, shade(paint, 60))
  grad.addColorStop(0.5, paint)
  grad.addColorStop(1, shade(paint, -40))
  g.fillStyle = grad

  // body
  g.beginPath()
  g.moveTo(-bw, h * 0.05)
  g.quadraticCurveTo(-bw * 1.06, -h * 0.02, -bw * 0.82, -h * 0.05)
  g.quadraticCurveTo(-bw * 0.45, -h * 0.155, bw * 0.05, -h * 0.15)
  g.quadraticCurveTo(bw * 0.6, -h * 0.135, bw * 0.92, -h * 0.05)
  g.quadraticCurveTo(bw * 1.08, -h * 0.015, bw, h * 0.05)
  g.closePath()
  g.fill()

  // glass
  g.fillStyle = 'rgba(10,16,24,0.9)'
  g.beginPath()
  g.moveTo(-bw * 0.42, -h * 0.135)
  g.quadraticCurveTo(-bw * 0.1, -h * 0.19, bw * 0.12, -h * 0.13)
  g.lineTo(bw * 0.05, -h * 0.09)
  g.lineTo(-bw * 0.38, -h * 0.09)
  g.closePath()
  g.fill()

  // wheels
  g.fillStyle = '#0c0d0f'
  const wy = h * 0.05
  const wheelXs = Math.abs(k) > 0.3 ? [-bw * 0.62, bw * 0.62] : [-bw * 0.62 * side, bw * 0.62 * side]
  for (const wx of wheelXs) {
    g.beginPath()
    g.ellipse(wx, wy, Math.max(Math.abs(k), 0.25) * w * 0.052, h * 0.052, 0, 0, Math.PI * 2)
    g.fill()
  }
  g.restore()
}

function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16)
  const c = (v) => Math.max(0, Math.min(255, v + amt))
  return `rgb(${c(n >> 16)},${c((n >> 8) & 255)},${c(n & 255)})`
}

export default function Fallback() {
  const canvas = useRef()
  const paint = useStore((s) => s.paint)
  const setPaint = useStore((s) => s.setPaint)
  const [frame, setFrame] = useState(0)
  const drag = useRef({ on: false, x: 0 })

  useEffect(() => {
    const el = canvas.current
    const g = el.getContext('2d')
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const w = el.clientWidth * dpr
    const h = el.clientHeight * dpr
    el.width = w
    el.height = h
    drawCarSilhouette(g, w, h, (frame / FRAMES) * Math.PI * 2, paint)
  }, [frame, paint])

  useEffect(() => {
    const id = setInterval(() => {
      if (!drag.current.on) setFrame((f) => (f + 1) % FRAMES)
    }, 120)
    return () => clearInterval(id)
  }, [])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#050607] px-6 text-center">
      <p className="text-[10px] uppercase tracking-[0.5em] text-white/40">AURION GT-S</p>
      <h1 className="mt-3 font-display text-4xl font-semibold text-white">360° Viewer</h1>
      <p className="mt-2 max-w-sm text-sm text-white/50">
        Your browser doesn't support WebGL — here's the lightweight viewer. Drag to rotate.
      </p>
      <canvas
        ref={canvas}
        className="mt-6 h-[300px] w-full max-w-xl cursor-grab touch-pan-y active:cursor-grabbing"
        onPointerDown={(e) => { drag.current = { on: true, x: e.clientX } }}
        onPointerMove={(e) => {
          if (!drag.current.on) return
          const dx = e.clientX - drag.current.x
          if (Math.abs(dx) > 12) {
            setFrame((f) => (f + (dx > 0 ? 1 : FRAMES - 1)) % FRAMES)
            drag.current.x = e.clientX
          }
        }}
        onPointerUp={() => { drag.current.on = false }}
      />
      <div className="mt-8 flex gap-3">
        {PAINTS.map((p) => (
          <button
            key={p.hex}
            type="button"
            aria-label={p.name}
            onClick={() => setPaint(p.hex)}
            className={`h-8 w-8 rounded-full border ${paint === p.hex ? 'border-white' : 'border-white/20'}`}
            style={{ background: p.hex }}
          />
        ))}
      </div>
    </div>
  )
}
