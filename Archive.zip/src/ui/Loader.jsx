import { useEffect, useState } from 'react'
import { useProgress } from '@react-three/drei'
import { useStore } from '../store.js'

export default function Loader() {
  const { progress, active } = useProgress()
  const loaded = useStore((s) => s.loaded)
  const setLoaded = useStore((s) => s.setLoaded)
  const [shown, setShown] = useState(0)
  const [gone, setGone] = useState(false)

  // Our scene is procedural (no async assets), so drive a fast cinematic
  // fill that also respects real loader progress if any assets register.
  useEffect(() => {
    let raf
    const start = performance.now()
    const tick = () => {
      const t = (performance.now() - start) / 1400
      const synthetic = Math.min(t * 100, 100)
      const real = active ? progress : 100
      const p = Math.min(synthetic, real < 100 ? Math.max(real, synthetic * 0.6) : 100)
      setShown(p)
      if (p >= 100) {
        setLoaded(true)
        setTimeout(() => setGone(true), 650)
      } else raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [active, progress, setLoaded])

  if (gone) return null
  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#050607] transition-opacity duration-500 ${loaded ? 'pointer-events-none opacity-0' : 'opacity-100'}`}
    >
      <p className="mb-3 font-display text-[11px] tracking-[0.6em] text-white/40">AURION</p>
      <p className="mb-10 font-display text-3xl font-semibold tracking-[0.25em] text-white">GT-S</p>
      <div className="h-px w-64 overflow-hidden bg-white/10">
        <div
          className="h-full bg-gradient-to-r from-sky-400 to-white transition-[width] duration-150 ease-out"
          style={{ width: `${shown}%` }}
        />
      </div>
      <p className="mt-4 font-mono text-[10px] tracking-widest text-white/35">
        {Math.round(shown).toString().padStart(3, '0')} — PREPARING STUDIO
      </p>
    </div>
  )
}
