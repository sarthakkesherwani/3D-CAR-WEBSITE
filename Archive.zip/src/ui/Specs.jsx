import { useEffect, useRef } from 'react'
import { gsap, ScrollTrigger } from '../gsapSetup.js'
import { SPECS } from '../config.js'

function fmt(v, spec) {
  const num = spec.decimals
    ? v.toFixed(spec.decimals)
    : Math.round(v).toLocaleString('en-US')
  return `${spec.prefix ?? ''}${num}${spec.suffix ?? ''}`
}

export default function Specs() {
  const root = useRef()

  useEffect(() => {
    const ctx = gsap.context(() => {
      const els = root.current.querySelectorAll('[data-count]')
      els.forEach((el, i) => {
        const spec = SPECS[i]
        const obj = { v: 0 }
        gsap.to(obj, {
          v: spec.value,
          duration: 1.8,
          ease: 'power3.out',
          delay: i * 0.12,
          scrollTrigger: { trigger: el, start: 'top 85%', once: true },
          onUpdate: () => { el.textContent = fmt(obj.v, spec) },
        })
      })
      gsap.from(root.current.querySelectorAll('[data-spec-row]'), {
        y: 36, opacity: 0, stagger: 0.1, duration: 0.9, ease: 'power3.out',
        scrollTrigger: { trigger: root.current, start: 'top 75%', once: true },
      })
    }, root)
    return () => ctx.revert()
  }, [])

  return (
    <div ref={root} className="pointer-events-auto mx-auto w-full max-w-4xl px-6">
      <p className="text-center text-[10px] uppercase tracking-[0.4em] text-sky-300/70">
        05 — By the numbers
      </p>
      <h2 className="mt-4 text-center font-display text-4xl font-semibold tracking-tight text-white md:text-5xl">
        Relentless, quantified
      </h2>
      <div className="mt-14 divide-y divide-white/10 border-y border-white/10">
        {SPECS.map((s, i) => (
          <div key={s.label} data-spec-row className="flex items-baseline justify-between py-6">
            <p className="text-xs uppercase tracking-[0.3em] text-white/45">{s.label}</p>
            <p data-count className="font-display text-4xl font-semibold tabular-nums text-white md:text-6xl">
              {fmt(0, s)}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
